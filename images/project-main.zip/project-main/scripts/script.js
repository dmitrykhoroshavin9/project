// Глобальная переменная для Swiper
let swiper;

document.addEventListener('DOMContentLoaded', () => {
    // Показываем прелоадер
    const preloader = document.querySelector('.preloader');

    // Функция загрузки данных
    async function loadCourses() {
        try {
            const response = await fetch('data.json');
            const data = await response.json();
            
            // Устанавливаем таймер на 1 секунду для демонстрации прелоадера
            setTimeout(() => {
                renderCourses(data.courses);
                // Скрываем прелоадер
                preloader.classList.add('fade-out');
                setTimeout(() => {
                    preloader.style.display = 'none';
                }, 500);
            }, 1000);
            
        } catch (error) {
            console.error('Ошибка загрузки данных:', error);
            preloader.style.display = 'none';
        }
    }

    // Функция рендеринга курсов
    function renderCourses(courses) {
        const coursesGrid = document.querySelector('.courses-grid');
        coursesGrid.innerHTML = '';

        for (let key in courses) {
            const course = courses[key];
            const courseHTML = `
                <article class="course-card">
                    <div class="course-image">
                        <img src="${course.image}" alt="${course.title}">
                    </div>
                    <div class="course-content">
                        <span class="course-category">${course.category}</span>
                        <h3>${course.title}</h3>
                        <p>${course.description}</p>
                        <div class="course-info">
                            <span><i class="icon-duration"></i> ${course.duration}</span>
                            <span><i class="icon-level"></i> ${course.level}</span>
                        </div>
                        <a href="#" class="btn-secondary">Подробнее</a>
                    </div>
                </article>
            `;
            coursesGrid.insertAdjacentHTML('beforeend', courseHTML);
        }
    }

    // Загружаем курсы
    loadCourses();

    // Фильтрация курсов
    const filterButtons = document.querySelectorAll('.filter-btn');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', async () => {
            filterButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');

            const filter = button.dataset.filter;
            
            try {
                const response = await fetch('data.json');
                const data = await response.json();
                
                if (filter === 'all') {
                    renderCourses(data.courses);
                    return;
                }

                const filteredCourses = {};
                for (let key in data.courses) {
                    if (data.courses[key].category.toLowerCase().includes(filter.toLowerCase())) {
                        filteredCourses[key] = data.courses[key];
                    }
                }
                
                renderCourses(filteredCourses);
            } catch (error) {
                console.error('Ошибка при фильтрации:', error);
            }
        });
    });

    // Инициализация Swiper
    try {
        swiper = new Swiper('.testimonials-slider', {
            slidesPerView: 1,
            spaceBetween: 30,
            loop: true,
            effect: 'fade',
            fadeEffect: {
                crossFade: true
            },
            
            autoplay: {
                delay: 5000,
                disableOnInteraction: false,
            },

            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },

            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },

            breakpoints: {
                768: {
                    slidesPerView: 1,
                    spaceBetween: 30
                }
            }
        });

        console.log('Swiper initialized successfully');
    } catch (error) {
        console.error('Error initializing Swiper:', error);
    }

    // FAQ раскрывающиеся ответы
    const faqItems = document.querySelectorAll('.faq-item');

    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');

        question.addEventListener('click', () => {
            // Переключаем активный класс для текущего вопроса
            item.classList.toggle('active');

            // Закрываем остальные вопросы
            faqItems.forEach(otherItem => {
                if (otherItem !== item && otherItem.classList.contains('active')) {
                    otherItem.classList.remove('active');
                }
            });
        });
    });

    // Обработка отправки формы
    const contactForm = document.querySelector('.contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const formData = new FormData(contactForm);
            alert('Форма отправлена!');
            contactForm.reset();
        });
    }

    // Модальные окна авторизации
    const loginBtn = document.getElementById('login-btn');
    const registerBtn = document.getElementById('register-btn');
    const loginModal = document.getElementById('loginModal');
    const registerModal = document.getElementById('registerModal');
    const closeLogin = document.getElementById('closeLogin');
    const closeRegister = document.getElementById('closeRegister');
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');

    loginBtn.addEventListener('click', function() {
        loginModal.classList.add('show');
    });

    registerBtn.addEventListener('click', function() {
        registerModal.classList.add('show');
    });

    closeLogin.addEventListener('click', function() {
        loginModal.classList.remove('show');
    });

    closeRegister.addEventListener('click', function() {
        registerModal.classList.remove('show');
    });

    window.addEventListener('click', function(event) {
        if (event.target === loginModal) {
            loginModal.classList.remove('show');
        }
        if (event.target === registerModal) {
            registerModal.classList.remove('show');
        }
    });

    loginForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;
        console.log('Login - Email:', email);
        console.log('Login - Password:', password);
        loginModal.classList.remove('show');
    });

    registerForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const email = document.getElementById('registerEmail').value;
        const username = document.getElementById('registerUsername').value;
        const password = document.getElementById('registerPassword').value;
        console.log('Register - Email:', email);
        console.log('Register - Username:', username);
        console.log('Register - Password:', password);
        registerModal.classList.remove('show');
    });
});